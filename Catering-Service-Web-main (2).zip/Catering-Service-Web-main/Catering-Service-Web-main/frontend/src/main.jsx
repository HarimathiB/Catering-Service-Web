import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import App from "./App";
import Events from "./components/Events";     // Events.jsx
import EventMenu from "./components/EventMenu";  // fixed path
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Router>
      <Routes>
        <Route path="/" element={<App />} />              {/* Homepage (App.jsx) */}
        <Route path="/events" element={<Events />} />      {/* Events page */}
        <Route path="/event/:eventName" element={<EventMenu />} /> {/* Event Menu */}
      </Routes>
    </Router>
  </React.StrictMode>
);
